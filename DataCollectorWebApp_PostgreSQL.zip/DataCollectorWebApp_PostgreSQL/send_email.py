
from email.mime.text import MIMEText  
import smtplib  


def sending_email( email, height, avg_height, cnt_height):  ## variable email,height pass from app.py 
    from_email='carillpower12345@gmail.com'  
    from_password='xxxxxxxxxxx'

    recepient = email
    subject = 'Height Data'
    message = 'Hi <br\>, your height data is :: <strong>%s</strong> <br\> Average Height is <strong>%s</strong> <br\> for total count of <strong>%s</strong> <br\>' % (height,avg_height,cnt_height)

    msg=MIMEText( message, 'html')  ## Convert as html type
    msg['Subject'] = subject
    msg['To'] = recepient
    msg['From'] = from_email

    gmail = smtplib.SMTP('smtp.gmail.com', 587)
    gmail.ehlo()
    gmail.starttls()
    gmail.login( from_email, from_password )
    gmail.send_message( msg )


    
