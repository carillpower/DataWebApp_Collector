

from flask import Flask, render_template, request, send_file  
from flask_sqlalchemy  import SQLAlchemy
from send_email import sending_email   

from sqlalchemy.sql import func    

from werkzeug.utils import secure_filename    

app=Flask(__name__)

### DB Configuration ##
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://shahril:xxxx@10.20.1.11:5432/supermarts'
app.config['SQLALCHEMY_ECHO'] = False
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db=SQLAlchemy(app)

class Data(db.Model):  
    __tablename__ = 'tbl1'  ## Create table tbl1
    id = db.Column( db.Integer, primary_key=True)  
    email_ = db.Column( db.String(120), unique=True) 
    height_ = db.Column( db.Integer )

    def __init__(self, email_, height_): 
        self.email_ = email_
        self.height_ = height_

#######################

@app.route('/')
def index():
    return render_template('index.html')    ## Will show page templates/index.html 

@app.route('/success', methods=['POST'])  
def success():
    if request.method == 'POST':
        email = request.form['email_name']  ## Take from html side
        height = request.form['height_name']  ## Take from html side

        if db.session.query(Data).filter(Data.email_ == email).count() == 0 :    ## If email not exist yet then store in DB
            data = Data(email, height)  ## Pass variable into Model function
            db.session.add( data )  
            db.session.commit()     

            avg_height = db.session.query( func.avg(Data.height_) ).scalar()  
            avg_height = round(avg_height,1)  
            cnt_height = db.session.query( Data.height_ ).count()

            sending_email(email, height, avg_height, cnt_height)

            return render_template('success.html')
        return render_template('index.html', text='Email already exists, try other email')    

@app.route('/upload')
def upload():   
    return render_template('upload.html')   

@app.route('/success_upload', methods=['POST'])
def success_upload():
    global files

    if request.method == 'POST':
        files = request.files['file']  
        files.save( secure_filename('uploaded_'+ files.filename) )   

        with open('uploaded_'+ files.filename, 'a') as f:
            f.write('Append new content into file')

        return render_template('upload.html', btn='download.html')

@app.route('/download')
def download():     ## Once click download, it will go here
    return send_file('uploaded_'+ files.filename, attachment_filename='user_dwld.csv', as_attachment=True)  ## attachement_filename is to rename the filename



## Main application start
if __name__ == '__main__':
    app.debug=True
    app.port=5000
    app.run()


